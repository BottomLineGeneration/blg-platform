# BLG Intelligence Platform

Telecom · Energy · NOI Optimization  
Bottom Line Generation | Byron Braun | byronbraun@bottomlinegeneration.com

---

## Deployment (One-Time Setup)

### Step 1 — Push to GitHub
1. Go to github.com → New repository → name it `blg-platform` → Create
2. Upload all these files (drag & drop in GitHub's UI works fine)

### Step 2 — Connect to Vercel
1. Go to vercel.com → Add New Project → Import from GitHub → select `blg-platform`
2. Framework: **Vite** (Vercel detects this automatically)
3. Click **Environment Variables** → Add:
   - Name:  `VITE_ANTHROPIC_KEY`
   - Value: `sk-ant-...` (your Anthropic API key)
4. Click **Deploy**

### Step 3 — Your live URL
Vercel gives you: `https://blg-platform.vercel.app`

---

## Adding a New Client

Each client gets their own isolated URL:

```
https://blg-platform.vercel.app?client=integracare
https://blg-platform.vercel.app?client=jamestown
https://blg-platform.vercel.app?client=any-name-you-choose
```

- Data is stored **per client** in the browser — never mixed
- Just make up a short URL-safe name (no spaces, lowercase)
- Tell Byron the client name → he gives you the URL → done

---

## Bigin CRM Integration

In Bigin Settings → Web Tabs → add:
```
https://blg-platform.vercel.app?client=[Company.Name]
```
Now every Company record has a BLG tab that opens pre-loaded for that client.

---

## How It Works

1. Open `?client=clientname` → blank dashboard for that client
2. Upload their invoices/bills/contracts → AI extracts all data
3. Review inventory → all services listed by location
4. View financial analysis → NOI, valuation uplift auto-calculated
5. Click **Export Report** → branded PDF opens, ready to print or share

---

Built by Bottom Line Generation | www.bottomlinegeneration.com
